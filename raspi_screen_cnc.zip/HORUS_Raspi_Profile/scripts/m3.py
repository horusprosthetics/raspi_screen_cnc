d.setSpindleState(SpindleState.CW_ON)
print("spindle ready")

