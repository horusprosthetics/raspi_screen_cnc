d.setSRO(50)
