d.setJogSpeed(1.5)
