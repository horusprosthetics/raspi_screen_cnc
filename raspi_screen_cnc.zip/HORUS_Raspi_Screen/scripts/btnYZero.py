d.setAxisProgPosition( Axis.Y, 0 )
