d.setAxisProgPosition( Axis.X, 0 )
