d.setAxisProgPosition( Axis.C, 0 )
