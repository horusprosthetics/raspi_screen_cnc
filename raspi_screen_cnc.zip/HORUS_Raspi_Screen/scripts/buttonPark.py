d.executeGCode( "G0G53 Z0" )
d.executeGCode( "G0G53 X0 Y0" )
