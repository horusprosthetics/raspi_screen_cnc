d.setFRO( 50 )
