d.setAxisProgPosition( Axis.Z, 0 )
