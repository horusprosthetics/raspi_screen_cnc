d.executeGCode( "G0G53 Z0" )
d.executeGCode( "G0 X0Y0" )
