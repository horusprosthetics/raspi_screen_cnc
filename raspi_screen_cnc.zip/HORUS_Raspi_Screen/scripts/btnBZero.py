d.setAxisProgPosition( Axis.B, 0 )
