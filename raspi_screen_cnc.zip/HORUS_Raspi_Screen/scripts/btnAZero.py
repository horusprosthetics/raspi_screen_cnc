d.setAxisProgPosition( Axis.A, 0 )
