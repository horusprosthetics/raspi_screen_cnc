d.setJogSpeed(100.0)
